var searchData=
[
  ['isconnected_96',['isConnected',['../class_bluetooth_a2_d_p_sink.html#a426488b357a83573cbcab893570700c5',1,'BluetoothA2DPSink::isConnected()'],['../class_bluetooth_a2_d_p_source.html#a4e98bae7828ded2e1dfd619d753b6c37',1,'BluetoothA2DPSource::isConnected()']]]
];
