var searchData=
[
  ['disconnect_87',['disconnect',['../class_bluetooth_a2_d_p_sink.html#a6d068787d5fbd7a462be743bb7b8cca3',1,'BluetoothA2DPSink']]],
  ['doloop_88',['doLoop',['../class_sound_data.html#ac79933ed3379cf5ef58d5675aa4bf12e',1,'SoundData']]]
];
