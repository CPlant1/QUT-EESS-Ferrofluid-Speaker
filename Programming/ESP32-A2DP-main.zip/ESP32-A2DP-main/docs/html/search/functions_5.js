var searchData=
[
  ['get2channeldata_90',['get2ChannelData',['../class_sound_data.html#aacc2d88868ceabde718113bd404452c3',1,'SoundData::get2ChannelData()'],['../class_two_channel_sound_data.html#a0a39d70aca39dbeca3d20676635b7615',1,'TwoChannelSoundData::get2ChannelData()'],['../class_one_channel_sound_data.html#a3ed4a75be0bb4dbb42752f5ae83badbb',1,'OneChannelSoundData::get2ChannelData()']]],
  ['get_5faudio_5fstate_91',['get_audio_state',['../class_bluetooth_a2_d_p_sink.html#af38d68b41544b8f0aba1bafb80f0ac75',1,'BluetoothA2DPSink']]],
  ['get_5faudio_5ftype_92',['get_audio_type',['../class_bluetooth_a2_d_p_sink.html#a77600cb1e36b7814eb9b4126cdec62d4',1,'BluetoothA2DPSink']]],
  ['get_5fconnection_5fstate_93',['get_connection_state',['../class_bluetooth_a2_d_p_sink.html#a785ef587a867d58ce31e466b1c68a96d',1,'BluetoothA2DPSink']]],
  ['get_5fvolume_94',['get_volume',['../class_bluetooth_a2_d_p_sink.html#aca1119f20d2321fb950ae859000cce7b',1,'BluetoothA2DPSink']]]
];
